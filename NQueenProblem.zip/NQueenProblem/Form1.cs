﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NQueenProblem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        double starttime;
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            starttime = System.DateTime.Now.TimeOfDay.TotalSeconds;
            switch (comboBox1.SelectedIndex)
            {
                case 0:
                    QueenQuestion(4);
                    break;
                case 1:
                    QueenQuestion(5);
                    break;
                case 2:
                    QueenQuestion(8);
                    break;
                case 3:
                    QueenQuestion(9);
                    break;
                case 4:
                    queenstxt(11);
                    break;
            }
        }
        public void QueenQuestion(int size)
        {
            string str = null;
            //定義棋盤陣列
            int[] queen = new int[size + 1];
            //定義bool變數判斷處理是否結束
            bool notFinish = true;
            //定義bool變數判斷當前位置是否與其它位置衝突
            bool ok = false;
            //當前處理的列數
            int current = 1;
            int k = 0;
            int count = 0;
            //初始化棋盤陣列的第一個陣列
            queen[current] = 1;
            while (notFinish)
            {
                //處理尚未結束，並且當前處理元素未到達第size個皇后
                while (notFinish && current <= size)
                {
                    //判斷是否有多個皇后在同一行
                    for (ok = true, k = 1; ok && k < current; k++)
                    {
                        if (queen[current] == queen[k])
                        {
                            ok = false;
                        }
                    }
                    //判斷是否有多個皇后在同一條對角線上
                    for (k = 1; ok && k < current; k++)
                    {
                        if (queen[current] == queen[k] + (k - current) || queen[current] == queen[k] - (k - current))
                        {
                            ok = false;
                        }
                    }
                    //如果有皇后位置相沖突
                    if (!ok)
                    {
                        //如果已經試探完該列所有位置
                        if (queen[current] == queen[current - 1])
                        {
                            //返回上一步
                            current--;
                            //如果列數大於一，並且皇后已到達最後一個位置
                            if (current > 1 && queen[current] == size)
                            {
                                //將皇后放到第一個位置
                                queen[current] = 1;
                            }
                            else if (current == 1 && queen[current] == size)
                            {
                                notFinish = false;
                            }
                            else
                            {
                                //皇后移動到下一個位置繼續試探
                                queen[current] += 1;
                            }
                        }
                        //如果皇后到達最後一個位置
                        else if (queen[current] == size)
                        {
                            queen[current] = 1;
                        }
                        else
                        {
                            queen[current] += 1;
                        }
                    }
                    else if (++current <= size)
                    {
                        if (queen[current - 1] == size)

                        {
                            queen[current] = 1;
                        }
                        else
                        {
                            queen[current] = queen[current - 1] + 1;
                        }
                    }
                }
                //找出一個解
                if (notFinish)
                {
                    //解的個數加一
                    count++;
                    str += count + " ： ";
                    //列印棋盤陣列
                    for (int i = 1; i <= size; i++)
                    {
                        str += +queen[i] + "， ";
                    }
                    str += "\r\n";

                    for (int i = 1; i <= size; i++)
                    {
                        for (int j = 1; j <= size; j++)
                        {
                            if (queen[i] == j) str += "Q ";
                            else
                            {
                                str += "－ ";
                            }
                        }
                        str += "\r\n";
                    }
                    str += "\r\n";
                    if (queen[size - 1] < size)
                    {
                        queen[size - 1]++;
                    }
                    else
                    {
                        queen[size - 1] = 1;
                    }
                    current = size - 1;
                }
            }
            textBox1.Text = str;
            double endtime = System.DateTime.Now.TimeOfDay.TotalSeconds;
            double totaltime = Math.Round(endtime - starttime, 3);
            str += "計時：" + totaltime;
            textBox1.Text = str + "秒\r\n" + (count) + "組解";
        }

        public void queenstxt(int size)
        {
            textBox1.Text = null;
            double stime = System.DateTime.Now.TimeOfDay.TotalSeconds;
            int[] queen = new int[size + 1];
            bool notFinish = true;
            bool ok = false;
            int current = 1;
            int k = 0;
            int count = 0;
            queen[current] = 1;
            SaveFileDialog SFD = new SaveFileDialog();
            SFD.Filter = "文字檔|*.txt|所有檔|*.*";
            SFD.Title = "儲存 N 皇后的結果";
            if (SFD.ShowDialog() == DialogResult.OK)
            {
                StreamWriter SW = new StreamWriter(SFD.FileName, false);
                while (notFinish)
                {
                    while (notFinish && current <= size)
                    {
                        for (ok = true, k = 1; ok && k < current; k++)
                        {
                            if (queen[current] == queen[k])
                            {
                                ok = false;
                            }
                        }
                        for (k = 1; ok && k < current; k++)
                        {
                            if (queen[current] == queen[k] + (k - current) || queen[current] == queen[k] - (k - current))
                            {
                                ok = false;
                            }
                        }
                        if (!ok)
                        {
                            if (queen[current] == queen[current - 1])
                            {
                                current--;
                                if (current > 1 && queen[current] == size)
                                {
                                    queen[current] = 1;
                                }
                                else if (current == 1 && queen[current] == size)
                                {
                                    notFinish = false;
                                }
                                else
                                {
                                    queen[current] += 1;
                                }
                            }
                            else if (queen[current] == size)
                            {
                                queen[current] = 1;
                            }
                            else
                            {
                                queen[current] += 1;
                            }
                        }
                        else if (++current <= size)
                        {
                            if (queen[current - 1] == size)

                            {
                                queen[current] = 1;
                            }
                            else
                            {
                                queen[current] = queen[current - 1] + 1;
                            }
                        }
                    }
                    if (notFinish)
                    {
                        count++;
                        SW.Write(count + " ： ");
                        for (int i = 1; i <= size; i++)
                        {
                            SW.Write(queen[i] + "， ");
                        }
                        SW.Write("\r\n");

                        for (int i = 1; i <= size; i++)
                        {
                            for (int j = 1; j <= size; j++)
                            {
                                if (queen[i] == j) SW.Write("Q ");
                                else
                                {
                                    SW.Write("－ ");
                                }
                            }
                            SW.Write("\r\n");
                        }
                        SW.Write("\r\n");
                        if (queen[size - 1] < size)
                        {
                            queen[size - 1]++;
                        }
                        else
                        {
                            queen[size - 1] = 1;
                        }
                        current = size - 1;
                    }

                }
                textBox1.Text += count + "組解\r\n";
                double endtime = System.DateTime.Now.TimeOfDay.TotalSeconds;
                double totaltime = Math.Round(endtime - stime, 3);
                textBox1.Text += "耗時" + totaltime + "秒";

            }
            System.Diagnostics.Process.Start(SFD.FileName);

        }
    }
}
//https://www.alotta.fans/forum/10188748.html
