﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20200527_Recursion_補強課程
{
    internal class RecursiveFunctions
    {
        public decimal RFact(ulong n)//Recursive Factorial
        {
            checked
            {
                if (n == 0 || n == 1) return 1;
                else return n*RFact(n-1);
            }
        }
        public decimal RFib(decimal n)
        {
            checked
            {
                if (n == 0) return 0;
                else if (n == 1) return 1;
                else
                {
                    return RFib(n-1)+RFib(n-2);
                }
            }
        }
        public decimal Rgcd(decimal x,decimal y)
        {
            if (x >= y)
            {
                if (x % y == 0) { return y; } //等於0代表整除,取較小數
                else { return Rgcd(y, x % y); }//遞迴呼叫
                
            }
            else
            {
                if (y%x==0) { return x; }
                else { return Rgcd(x,y%x); }
            }
        }
        public void BubbleSort(int[] A,int first,int last)
        {
            int temp;
            if (first == last) return;
            for (int j = first; j < last; j++)
            {
               
                    if (A[j] > A[j + 1])
                    {
                        temp = A[j];
                        A[j] = A[j + 1];
                        A[j + 1] = temp;
                    }
                
            }
            BubbleSort(A,first,last-1);
        }
        public void QuickSort(int[] A,int left,int right)
        {
            int temp;
            if (left < right)
            {
                int i = left;
                int j = right + 1;
                while (true)
                {
                    while (i + 1 < A.Length && A[++i] < A[left]) ;
                    while (j - 1 > -1 && A[--j] > A[left]) ;
                    if (i >= j) break;

                    //Swap(A,i,j);
                    temp = A[i];
                    A[i] = A[j];
                    A[j]=temp;
                }
                //Swap(array,left,j);
                temp = A[left];
                A[left] = A[j];
                A[j] = temp;
                //
                QuickSort(A,left,j-1);
                QuickSort(A,j+1,right);
                
            }
        }
        public int BinarySearch(string[] ID, string X, int first ,int last)
        {
            int midptr = (first + last) / 2;
            if (ID[midptr] == X) return midptr;
            else if (first >= last) return -1;
            else if (string.Compare(X, ID[midptr]) < 0) return BinarySearch(ID, X, first, midptr - 1);
            else return BinarySearch(ID, X, midptr + 1, last);
        }
    }

}
